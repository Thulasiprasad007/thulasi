import java.util.*;

class Teacher
{
public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
double[] num=new double[10];
double score=0;int flag=1,turn=0;
while(flag==1)
{
	if(turn==3)
	{System.out.println("Turns limit reached");break;}
	else{
	System.out.println("Enter n value");
	int n=s.nextInt();
	for(int i=1;i<=n;i++)
	{
	System.out.println("Enter the num");
	num[i]=s.nextDouble();
	if(num[i]%2==1)
		score=score+1;
	else if(num[i]%2==0)
		score=score-0.5;
	else if(num[i]<0)
		{score=score-1;flag=-1;}
	}
	System.out.println("Score: " +score);
	}
	turn++;	
}
}
}