import java.util.Scanner;

class Bird {

public static void main(String[] args)  
{ 
    Scanner s=new Scanner(System.in);
    System.out.println("The bird said..");
    int n=s.nextInt(),sum=0;
    while (n!=0) 
    { 
        sum=sum+n%10; 
        n=n/10; 
    } 
    System.out.println("Patrick and Johnny must go in path "+ sum+" to find Alice");
}
}
