import java.util.Scanner;
class PrintAllBetweenInterval{
	public static void main(String[] args){
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value of a");
		int a=s.nextInt();
		System.out.println("Enter the value of b");
		int b=s.nextInt();
		for(int i=a;i<=b;i++){
			System.out.println(i);
		}
	}
}