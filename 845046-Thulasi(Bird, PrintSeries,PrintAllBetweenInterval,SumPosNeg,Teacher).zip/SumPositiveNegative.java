import java.util.Scanner;

class SumPositiveNegative{

public static void main(String[] args)  
{ 
    Scanner s=new Scanner(System.in);
    int[] num=new int[10];
    int pos=0, neg=0;
    System.out.println("Enter value of n");
    int n=s.nextInt();
    for(int i=0;i<n;i++)
    {
        System.out.println("Enter number");
        num[i]=s.nextInt();
        if(num[i]>0){
            pos=pos+num[i];
        }
        else{
            neg=neg+num[i];
        }
    }
    System.out.println("Sum of positive numbers "+pos);
    System.out.println("Sum of negative numbers "+neg);
}
}
