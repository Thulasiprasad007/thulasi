import java.lang.StringBuffer;
class StringBufferExample
{
	public static void main(String[] args)
	{
		StringBuffer s=new StringBuffer("This is StringBuffer");
		System.out.println("\nBefore appending: "+s);
		s.append("- This is a sample program");
		System.out.println("\nAfter appending: "+s);
		s.insert(21, "Object");
		System.out.println("\nInserting Object at postion 21: "+s);
		s.replace(14,20,"Builder");
		System.out.println("\nreplace buffer with builder: "+s);
		System.out.println("\nreverse:"+s.reverse());
		
	}
}