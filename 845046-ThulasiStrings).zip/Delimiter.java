import java.lang.*;

class Delimiter
{
	public static void main(String[] args)
	{
		String s = new String("C:\\IBM\\DB2\\PROGRAM\\DB2COPY1.EXE");
		String strPiped =s.replace("\\"," || ");
		System.out.println(strPiped);
		String drive=strPiped.substring(0,3);
		String folder=strPiped.substring(6,28);
		String file=strPiped.substring(31,43);
		System.out.println("Drive: "+drive);
		System.out.println("Folder: "+folder);
		System.out.println("File: "+file);
		
	}
}