import java.lang.String;

class WelcometoJavaString
{
	public static void main(String[] aegs)
	{
		String str="Welcome to Java World";
		System.out.println("\nCharacter at 5th position:"+str.charAt(5));
		System.out.println("\nComparing str with Welcome(ignoring case):"+str.compareToIgnoreCase("Welcome")+"("+str.equalsIgnoreCase("Welcome")+")");
		System.out.println("\nConcatenation: "+str.concat("- Let us Learn"));
		System.out.println("\nFirst occurence of character 'a': "+str.indexOf('a'));
		System.out.println("\nString between 4th position and 10th position:"+str.substring(4,10));
		System.out.println("\nString in lowercase:"+str.toLowerCase());
	}
}