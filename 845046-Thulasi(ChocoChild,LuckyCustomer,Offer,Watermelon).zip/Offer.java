import java.util.Scanner;

class Offer
{
public static double min(double val1, double val2, double val3){
double least=0;
if(val1<val2 && val1<val3)
return val1;
else if(val2<val1 && val2<val3)
return val2;
else
return val3;
}
public static void main(String[] args)
{
Scanner s = new Scanner(System.in);
double prod1=0,prod2=0,prod3=0,total=0,offer1,offer2;
System.out.println("Enter 3 products cost:");
prod1=s.nextDouble();
prod2=s.nextDouble();
prod3=s.nextDouble();
total=prod1+prod2+prod3;
offer1=total-(total*0.2);
offer2=min(prod1,prod2,prod3);

System.out.println("\nTotal: Rs."+total);
System.out.println("Offer1: Rs."+offer1);
System.out.println("Offer2: Rs."+offer2);
if(offer2<offer1)
	System.out.println("\nGo for offer 2");
else
	System.out.println("\nGo for offer 1");

}
}