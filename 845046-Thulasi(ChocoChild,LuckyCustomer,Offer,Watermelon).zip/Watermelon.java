import java.util.Scanner;
class Watermelon
{
public static void main(String[] args)
{
Scanner s = new Scanner(System.in);
System.out.println("Enter weight of watermelon..");
int weight=s.nextInt();
int share=0;
if(weight%2==0)
{
share=weight/2;
System.out.println("Sibling1 | Sibling2");
for(int i=1;i<share;i++,share--)
{
System.out.println(i+"/"+(share-1)+"      | "+(share-1)+"/"+i);
}
}
else
{
System.out.println("Cant divide share");
} 
}
}