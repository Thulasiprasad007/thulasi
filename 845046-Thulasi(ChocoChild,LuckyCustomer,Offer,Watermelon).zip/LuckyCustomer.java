import java.util.Scanner;
class LuckyCustomer
{
    public static void main(String[] args)
    {   
        Scanner s=new Scanner(System.in);
        System.out.println("BillNo: ");
        int billNo=s.nextInt();
        System.out.println("Date(dd): ");
        int date=s.nextInt();
        int last1=billNo%10;
        int last2=billNo%100;
        
        if((date>0 && date<=31) && ((billNo%date)==0 || last1==date || last2==date))
            System.out.println("Lucky Customer");
        else
            System.out.println("Better Luck next time");
    }
}