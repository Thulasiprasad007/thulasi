import java.util.Scanner;
class ChocoChild
{
public static void main(String[] args)
{
    int giveChoc=0, overChoc=0, overChild=0;
    Scanner s=new Scanner(System.in);
    System.out.println("No. of Chocolates: ");
    int numChoc=s.nextInt();
    System.out.println("No. of Children: ");
    int numChild=s.nextInt();
    for(int i=1;i<=numChild;i++)
    {
        giveChoc=giveChoc+i;
        if(giveChoc>=numChoc){
            overChoc=giveChoc-i;
            if(i<=numChild){
                i--;
            }
            overChild=i;
            break;
        }
    }
    System.out.println();
    if(giveChoc<numChoc)
    {
        System.out.println(giveChoc+" Chocolates were given to "+numChild+" Children");
        System.out.println("Remaining Chocolates "+(numChoc-giveChoc));
    }
    else{
        System.out.println(overChoc+" Chocolates were given to "+overChild+" Children");
        System.out.println("Remaining Children "+(numChild-overChild));
    }
}
}