import java.util.Scanner;
class NumberofTurns
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		int target=s.nextInt();
		int[] turn=new int[10];
		int score=0,totalTurns=0;
		for(int i=1;i<=10;i++)
		{
			turn[i]=s.nextInt();
			score=score+turn[i];
			if(score>=target){
				totalTurns=i;
				break;
			}
		}
		System.out.println("The number of turns is "+totalTurns);
	}
}