import java.util.*;
class LargestSquare
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int side=(n/4)*2;
		int squareArea=side*side; 
		System.out.println(squareArea);
	}
}