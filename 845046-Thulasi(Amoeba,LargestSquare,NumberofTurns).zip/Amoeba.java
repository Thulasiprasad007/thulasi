import java.util.Scanner;
class Amoeba
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of months..");
		int month=s.nextInt();
		int first=0, second=1, t=0;
		for(int i=3;i<=month;i++)
		{
			t=first+second;
			first=second;
			second=t;
		}
		System.out.println("The Amoeba size is "+t);
	}
}